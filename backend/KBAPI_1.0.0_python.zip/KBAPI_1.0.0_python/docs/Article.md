# Article

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**article_id** | **str** |  | [optional] 
**section** | **str** |  | [optional] 
**subsection** | **str** |  | [optional] 
**question** | **str** |  | [optional] 
**answer** | **str** |  | [optional] 
**updated_on** | **str** |  | [optional] 
**tags** | **list[str]** |  | [optional] 
**key_terms** | **list[str]** |  | [optional] 
**keycodes** | **list[str]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


