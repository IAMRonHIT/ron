# openapi_client.DefaultApi

All URIs are relative to *https://server/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_article**](DefaultApi.md#get_article) | **GET** /articles/{id} | 
[**get_article_summaries**](DefaultApi.md#get_article_summaries) | **GET** /articles/summary | 


# **get_article**
> Article get_article(id, x_system_id, x_organization_id, x_user_id)



### Example

* OAuth Authentication (default):
```python
from __future__ import print_function
import time
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint
configuration = openapi_client.Configuration()
# Configure OAuth2 access token for authorization: default
configuration.access_token = 'YOUR_ACCESS_TOKEN'
configuration = openapi_client.Configuration()
# Configure API key authorization: gateway_authorizer
configuration.api_key['Unused'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Unused'] = 'Bearer'

# create an instance of the API class
api_instance = openapi_client.DefaultApi(openapi_client.ApiClient(configuration))
id = 'id_example' # str | 
x_system_id = 'x_system_id_example' # str | Unique Identifier that is associated with the System in Use. This is the Licensee User. Example: American Medical Association could be AMA39300
x_organization_id = 'x_organization_id_example' # str | Unique Identifier associated with the organization using the content. Example: John Smith Organization could be JSmithOrg2024
x_user_id = 'x_user_id_example' # str | Unique Identifier associated with the individual logged-in user. Example: John Smith could be Jsmith20

try:
    api_response = api_instance.get_article(id, x_system_id, x_organization_id, x_user_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->get_article: %s\n" % e)
```

* Api Key Authentication (gateway_authorizer):
```python
from __future__ import print_function
import time
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint
configuration = openapi_client.Configuration()
# Configure OAuth2 access token for authorization: default
configuration.access_token = 'YOUR_ACCESS_TOKEN'
configuration = openapi_client.Configuration()
# Configure API key authorization: gateway_authorizer
configuration.api_key['Unused'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Unused'] = 'Bearer'

# create an instance of the API class
api_instance = openapi_client.DefaultApi(openapi_client.ApiClient(configuration))
id = 'id_example' # str | 
x_system_id = 'x_system_id_example' # str | Unique Identifier that is associated with the System in Use. This is the Licensee User. Example: American Medical Association could be AMA39300
x_organization_id = 'x_organization_id_example' # str | Unique Identifier associated with the organization using the content. Example: John Smith Organization could be JSmithOrg2024
x_user_id = 'x_user_id_example' # str | Unique Identifier associated with the individual logged-in user. Example: John Smith could be Jsmith20

try:
    api_response = api_instance.get_article(id, x_system_id, x_organization_id, x_user_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->get_article: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**|  | 
 **x_system_id** | **str**| Unique Identifier that is associated with the System in Use. This is the Licensee User. Example: American Medical Association could be AMA39300 | 
 **x_organization_id** | **str**| Unique Identifier associated with the organization using the content. Example: John Smith Organization could be JSmithOrg2024 | 
 **x_user_id** | **str**| Unique Identifier associated with the individual logged-in user. Example: John Smith could be Jsmith20 | 

### Return type

[**Article**](Article.md)

### Authorization

[default](../README.md#default), [gateway_authorizer](../README.md#gateway_authorizer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | 200 response |  -  |
**400** | 400 response |  -  |
**401** | 401 response |  -  |
**403** | 403 response |  -  |
**408** | 408 response |  -  |
**500** | 500 response |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_article_summaries**
> list[Article] get_article_summaries(x_system_id, x_organization_id, x_user_id, keyword=keyword, section=section, subsection=subsection, tag=tag, keycode=keycode, key_terms=key_terms, updated_after_date=updated_after_date, updated_before_date=updated_before_date, exact_match=exact_match, index=index, results=results)



### Example

* OAuth Authentication (default):
```python
from __future__ import print_function
import time
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint
configuration = openapi_client.Configuration()
# Configure OAuth2 access token for authorization: default
configuration.access_token = 'YOUR_ACCESS_TOKEN'
configuration = openapi_client.Configuration()
# Configure API key authorization: gateway_authorizer
configuration.api_key['Unused'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Unused'] = 'Bearer'

# create an instance of the API class
api_instance = openapi_client.DefaultApi(openapi_client.ApiClient(configuration))
x_system_id = 'x_system_id_example' # str | Unique Identifier that is associated with the System in Use. This is the Licensee User. Example: American Medical Association could be AMA39300
x_organization_id = 'x_organization_id_example' # str | Unique Identifier associated with the organization using the content. Example: John Smith Organization could be JSmithOrg2024
x_user_id = 'x_user_id_example' # str | Unique Identifier associated with the individual logged-in user. Example: John Smith could be Jsmith20
keyword = ['keyword_example'] # list[str] |  (optional)
section = ['section_example'] # list[str] |  (optional)
subsection = ['subsection_example'] # list[str] |  (optional)
tag = ['tag_example'] # list[str] | A list of tag by which articles are to be filtered (optional)
keycode = ['keycode_example'] # list[str] | A list of keycodes by which articles are to be filtered (optional)
key_terms = ['key_terms_example'] # list[str] | A list of key terms by which articles are to be filtered (optional)
updated_after_date = 'updated_after_date_example' # str | Date in 'YYYY-MM-DD' Format (optional)
updated_before_date = 'updated_before_date_example' # str | Date in 'YYYY-MM-DD' Format (optional)
exact_match = True # bool | true/ false (optional)
index = 'index_example' # str | Fetch results from record number (Starts from 0) (optional)
results = 'results_example' # str | Number of articles to fetch (optional)

try:
    api_response = api_instance.get_article_summaries(x_system_id, x_organization_id, x_user_id, keyword=keyword, section=section, subsection=subsection, tag=tag, keycode=keycode, key_terms=key_terms, updated_after_date=updated_after_date, updated_before_date=updated_before_date, exact_match=exact_match, index=index, results=results)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->get_article_summaries: %s\n" % e)
```

* Api Key Authentication (gateway_authorizer):
```python
from __future__ import print_function
import time
import openapi_client
from openapi_client.rest import ApiException
from pprint import pprint
configuration = openapi_client.Configuration()
# Configure OAuth2 access token for authorization: default
configuration.access_token = 'YOUR_ACCESS_TOKEN'
configuration = openapi_client.Configuration()
# Configure API key authorization: gateway_authorizer
configuration.api_key['Unused'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Unused'] = 'Bearer'

# create an instance of the API class
api_instance = openapi_client.DefaultApi(openapi_client.ApiClient(configuration))
x_system_id = 'x_system_id_example' # str | Unique Identifier that is associated with the System in Use. This is the Licensee User. Example: American Medical Association could be AMA39300
x_organization_id = 'x_organization_id_example' # str | Unique Identifier associated with the organization using the content. Example: John Smith Organization could be JSmithOrg2024
x_user_id = 'x_user_id_example' # str | Unique Identifier associated with the individual logged-in user. Example: John Smith could be Jsmith20
keyword = ['keyword_example'] # list[str] |  (optional)
section = ['section_example'] # list[str] |  (optional)
subsection = ['subsection_example'] # list[str] |  (optional)
tag = ['tag_example'] # list[str] | A list of tag by which articles are to be filtered (optional)
keycode = ['keycode_example'] # list[str] | A list of keycodes by which articles are to be filtered (optional)
key_terms = ['key_terms_example'] # list[str] | A list of key terms by which articles are to be filtered (optional)
updated_after_date = 'updated_after_date_example' # str | Date in 'YYYY-MM-DD' Format (optional)
updated_before_date = 'updated_before_date_example' # str | Date in 'YYYY-MM-DD' Format (optional)
exact_match = True # bool | true/ false (optional)
index = 'index_example' # str | Fetch results from record number (Starts from 0) (optional)
results = 'results_example' # str | Number of articles to fetch (optional)

try:
    api_response = api_instance.get_article_summaries(x_system_id, x_organization_id, x_user_id, keyword=keyword, section=section, subsection=subsection, tag=tag, keycode=keycode, key_terms=key_terms, updated_after_date=updated_after_date, updated_before_date=updated_before_date, exact_match=exact_match, index=index, results=results)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->get_article_summaries: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **x_system_id** | **str**| Unique Identifier that is associated with the System in Use. This is the Licensee User. Example: American Medical Association could be AMA39300 | 
 **x_organization_id** | **str**| Unique Identifier associated with the organization using the content. Example: John Smith Organization could be JSmithOrg2024 | 
 **x_user_id** | **str**| Unique Identifier associated with the individual logged-in user. Example: John Smith could be Jsmith20 | 
 **keyword** | [**list[str]**](str.md)|  | [optional] 
 **section** | [**list[str]**](str.md)|  | [optional] 
 **subsection** | [**list[str]**](str.md)|  | [optional] 
 **tag** | [**list[str]**](str.md)| A list of tag by which articles are to be filtered | [optional] 
 **keycode** | [**list[str]**](str.md)| A list of keycodes by which articles are to be filtered | [optional] 
 **key_terms** | [**list[str]**](str.md)| A list of key terms by which articles are to be filtered | [optional] 
 **updated_after_date** | **str**| Date in &#39;YYYY-MM-DD&#39; Format | [optional] 
 **updated_before_date** | **str**| Date in &#39;YYYY-MM-DD&#39; Format | [optional] 
 **exact_match** | **bool**| true/ false | [optional] 
 **index** | **str**| Fetch results from record number (Starts from 0) | [optional] 
 **results** | **str**| Number of articles to fetch | [optional] 

### Return type

[**list[Article]**](Article.md)

### Authorization

[default](../README.md#default), [gateway_authorizer](../README.md#gateway_authorizer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | 200 response |  -  |
**400** | 400 response |  -  |
**401** | 401 response |  -  |
**403** | 403 response |  -  |
**408** | 408 response |  -  |
**500** | 500 response |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

